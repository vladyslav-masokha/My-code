'use strict';
// TODO: Navigation
$('.close').click(function () {
	$('.nav').addClass('un-active-navbar');
});

$('.check-burger').click(function () {
	$('.nav').removeClass('un-active-navbar');
});
